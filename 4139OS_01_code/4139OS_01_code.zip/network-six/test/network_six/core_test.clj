(ns network-six.core-test
  (:use clojure.test
        network-six.core))

(deftest a-test
  (testing "FIXME, I fail."
    (is (= 0 1))))
