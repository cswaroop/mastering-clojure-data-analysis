(ns tm-sotu.core-test
  (:use clojure.test
        tm-sotu.core))

(deftest a-test
  (testing "FIXME, I fail."
    (is (= 0 1))))
